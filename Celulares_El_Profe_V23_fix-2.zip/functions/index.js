const { onDocumentCreated, onDocumentWritten } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");
const logger = require("firebase-functions/logger");

initializeApp();

const db = getFirestore();

// Correos de administradores (mismos que en la app y en las reglas).
const ADMIN_EMAILS = [
  "juancarlospelayolepe7@gmail.com",
  "manololepe25@gmail.com"
];

async function sendToToken(token, title, body, data = {}) {
  if (!token) return false;
  try {
    await getMessaging().send({
      token,
      notification: { title, body },
      data: Object.fromEntries(
        Object.entries(data).map(([k, v]) => [k, String(v ?? "")])
      ),
      android: {
        priority: "high",
        notification: {
          channelId: "celulares_el_profe_mensajes",
          sound: "default",
          defaultSound: true,
          defaultVibrateTimings: true
        }
      }
    });
    return true;
  } catch (error) {
    logger.warn("Fallo al enviar FCM", { error: error.message, code: error.code });
    if (
      error.code === "messaging/registration-token-not-registered" ||
      error.code === "messaging/invalid-registration-token"
    ) {
      return "invalid_token";
    }
    return false;
  }
}

async function sendToUser(uid, title, body, data = {}) {
  const userSnap = await db.collection("users").doc(uid).get();
  if (!userSnap.exists) return;
  const token = userSnap.get("fcmToken");
  const result = await sendToToken(token, title, body, data);
  if (result === "invalid_token") {
    await db.collection("users").doc(uid).set({ fcmToken: null }, { merge: true });
  }
}

async function getAllAdminUids() {
  const uids = new Set();

  // Por role = admin
  const byRole = await db.collection("users").where("role", "==", "admin").get();
  byRole.docs.forEach((d) => uids.add(d.id));

  // Por correos conocidos (por si aún no tienen role escrito)
  for (const email of ADMIN_EMAILS) {
    const byEmail = await db.collection("users").where("email", "==", email).get();
    byEmail.docs.forEach((d) => uids.add(d.id));
  }

  return [...uids];
}

/**
 * Notificación de mensajes privados.
 * - Cliente → ADMIN: notifica a TODOS los administradores.
 * - Admin/cliente → uid concreto: notifica a ese destinatario.
 */
exports.notifyPrivateMessage = onDocumentCreated(
  "privateMessages/{messageId}",
  async (event) => {
    const snapshot = event.data;
    if (!snapshot) return;

    const message = snapshot.data() || {};
    const senderUid = String(message.senderUid || "");
    const recipientUid = String(message.recipientUid || "");
    const text = String(message.text || "").trim();
    if (!senderUid || !recipientUid || !text) return;

    const senderName = String(message.senderEmail || "Cliente");
    const preview = text.length > 120 ? `${text.slice(0, 117)}...` : text;
    const messageId = event.params.messageId;

    if (recipientUid === "ADMIN") {
      const adminUids = await getAllAdminUids();
      logger.info("Notificando mensaje a administradores", { count: adminUids.length });
      await Promise.all(
        adminUids.map((uid) =>
          sendToUser(
            uid,
            "💬 Nuevo mensaje",
            `${senderName}: ${preview}`,
            { type: "private_message", messageId }
          )
        )
      );
      return;
    }

    // Destinatario concreto (cliente o admin por UID)
    const recipientSnap = await db.collection("users").doc(recipientUid).get();
    const recipientRole = recipientSnap.exists
      ? String(recipientSnap.get("role") || "").toLowerCase()
      : "";
    const isAdminRecipient = recipientRole === "admin";

    await sendToUser(
      recipientUid,
      isAdminRecipient ? "💬 Nuevo mensaje" : "💬 Celulares El Profe",
      isAdminRecipient ? `${senderName}: ${preview}` : preview,
      { type: "private_message", messageId }
    );
  }
);

/**
 * Notificación de avisos generales.
 * Cuando el admin publica un aviso en appSettings/main (campo notices),
 * se envía una push a todos los dispositivos suscritos al topic "avisos_generales".
 */
exports.notifyAppNotice = onDocumentWritten(
  "appSettings/main",
  async (event) => {
    const before = event.data?.before?.data() || {};
    const after = event.data?.after?.data() || {};

    const beforeNotices = Array.isArray(before.notices) ? before.notices : [];
    const afterNotices = Array.isArray(after.notices) ? after.notices : [];

    // Solo si se agregó al menos un aviso nuevo
    if (afterNotices.length <= beforeNotices.length) return;

    const newest = String(afterNotices[0] || "").trim();
    if (!newest) return;

    const preview = newest.length > 140 ? `${newest.slice(0, 137)}...` : newest;

    try {
      await getMessaging().send({
        topic: "avisos_generales",
        notification: {
          title: "📢 Aviso de Celulares El Profe",
          body: preview
        },
        data: {
          type: "aviso",
          body: preview
        },
        android: {
          priority: "high",
          notification: {
            channelId: "celulares_el_profe_mensajes",
            sound: "default",
            defaultSound: true,
            defaultVibrateTimings: true
          }
        }
      });
      logger.info("Aviso general enviado al topic avisos_generales");
    } catch (error) {
      logger.error("No se pudo enviar el aviso general", { error: error.message });
    }
  }
);
