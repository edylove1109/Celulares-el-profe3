package com.celulareselprofe.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {
    companion object {
        const val CHANNEL_ID = "celulares_el_profe_mensajes"
        const val CHANNEL_NAME = "Mensajes y avisos"
        const val TOPIC_AVISOS = "avisos_generales"
    }

    override fun onNewToken(token: String) {
        // Guarda el token del dispositivo siempre que se renueve.
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid != null) {
            FirebaseFirestore.getInstance().collection("users").document(uid)
                .set(mapOf("fcmToken" to token), SetOptions.merge())
        }
        // Se mantiene suscrito al topic de avisos generales.
        com.google.firebase.messaging.FirebaseMessaging.getInstance()
            .subscribeToTopic(TOPIC_AVISOS)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)

        // Funciona tanto si llega payload "notification" como solo "data"
        // (cuando la app está en primer plano o segundo plano).
        val title = message.notification?.title
            ?: message.data["title"]
            ?: when (message.data["type"]) {
                "aviso" -> "📢 Aviso de Celulares El Profe"
                "private_message" -> "💬 Celulares El Profe"
                else -> "Celulares El Profe"
            }

        val body = message.notification?.body
            ?: message.data["body"]
            ?: message.data["text"]
            ?: "Tienes una nueva notificación."

        showNotification(title, body, message.data["type"])
    }

    private fun showNotification(title: String, body: String, type: String?) {
        createNotificationChannel()
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("open_messages", type == "private_message")
            putExtra("open_avisos", type == "aviso")
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            (System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()
        try {
            NotificationManagerCompat.from(this)
                .notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
        } catch (_: SecurityException) {
            // Android 13+: el usuario pudo denegar POST_NOTIFICATIONS.
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            CHANNEL_NAME,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notificaciones de mensajes y avisos de Celulares El Profe"
            enableVibration(true)
            setShowBadge(true)
        }
        manager.createNotificationChannel(channel)
    }
}
