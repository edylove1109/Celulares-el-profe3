package com.celulareselprofe.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private companion object {
        // Todos los correos de esta lista tienen permisos de administrador completos e idénticos.
        // Agrega aquí el correo del segundo administrador para que quede bootstrap automático.
        val ADMIN_EMAILS = setOf(
            "juancarlospelayolepe7@gmail.com",
            "manololepe25@gmail.com"
        )

        fun isKnownAdminEmail(email: String?): Boolean {
            if (email.isNullOrBlank()) return false
            return ADMIN_EMAILS.any { it.equals(email.trim(), ignoreCase = true) }
        }

        fun isAdminRole(role: String?): Boolean {
            return role?.trim()?.equals("admin", ignoreCase = true) == true
        }
    }
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var status: TextView
    private var appWebView: WebView? = null
    private var filePathCallback: ValueCallback<Array<android.net.Uri>>? = null
    private val fileChooserRequestCode = 9001
    private var mediaUploadCallback: String? = null
    private var mediaUploadMime: String? = null

    override fun onDestroy() {
        appWebView?.let {
            try { (it.getTag() as? NativeAppBridge)?.releaseListeners() } catch (_: Exception) { }
        }
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        ensureNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        showSplashThenContinue()
    }

    /** Reproduce el video de introducción a pantalla completa y, al terminar (o si el usuario lo toca para saltar), continúa al login o al catálogo. */
    private fun showSplashThenContinue() {
        setContentView(R.layout.activity_splash)
        val videoView = findViewById<android.widget.VideoView>(R.id.splashVideo)
        var proceeded = false
        val proceed = {
            if (!proceeded) {
                proceeded = true
                if (auth.currentUser != null) loadUserAndOpen() else showLogin()
            }
        }
        try {
            val uri = android.net.Uri.parse("file:///android_asset/intro.mp4")
            videoView.setVideoURI(uri)
            videoView.setOnCompletionListener { proceed() }
            videoView.setOnErrorListener { _, _, _ -> proceed(); true }
            videoView.setOnPreparedListener { it.isLooping = false }
            videoView.start()
        } catch (_: Exception) {
            proceed()
        }
        // Permite saltar el video tocando la pantalla.
        videoView.setOnClickListener { proceed() }
        // Salvaguarda: si el video dura más de 15s o falla en avisar, continúa igualmente.
        videoView.postDelayed({ proceed() }, 15000)
    }

    /** Crea el canal de notificaciones al arrancar (Android 8+). */
    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(android.app.NotificationManager::class.java) ?: return
        val channel = android.app.NotificationChannel(
            MyFirebaseMessagingService.CHANNEL_ID,
            MyFirebaseMessagingService.CHANNEL_NAME,
            android.app.NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notificaciones de mensajes y avisos de Celulares El Profe"
            enableVibration(true)
            setShowBadge(true)
        }
        manager.createNotificationChannel(channel)
    }

    private fun showLogin() {
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        val email = findViewById<EditText>(R.id.email)
        val pass = findViewById<EditText>(R.id.password)
        findViewById<Button>(R.id.login).setOnClickListener { login(email.text.toString().trim(), pass.text.toString()) }
        findViewById<Button>(R.id.register).setOnClickListener { register(email.text.toString().trim(), pass.text.toString()) }
    }

    private fun login(email: String, pass: String) {
        val cleanEmail = email.trim().lowercase()
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            status.text = "Escribe un correo electrónico válido."
            return
        }
        if (pass.isBlank()) {
            status.text = "Escribe tu contraseña."
            return
        }
        status.text = "Entrando…"
        auth.signInWithEmailAndPassword(cleanEmail, pass).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                loadUserAndOpen()
            } else {
                status.text = authErrorMessage(task.exception, false)
            }
        }
    }

    private fun register(email: String, pass: String) {
        val cleanEmail = email.trim().lowercase()
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            status.text = "Escribe un correo electrónico válido."
            return
        }
        if (pass.length < 8) {
            status.text = "La contraseña debe tener al menos 8 caracteres."
            return
        }
        status.text = "Creando cuenta…"
        auth.createUserWithEmailAndPassword(cleanEmail, pass).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val user = task.result?.user
                if (user != null) {
                    val base = hashMapOf<String, Any>(
                        "email" to cleanEmail,
                        "createdAt" to System.currentTimeMillis()
                    )
                    db.collection("users").document(user.uid)
                        .set(base, SetOptions.merge())
                        .addOnCompleteListener {
                            loadUserAndOpen()
                        }
                } else {
                    status.text = "Cuenta creada, pero no se pudo abrir la sesión. Intenta entrar."
                }
            } else {
                status.text = authErrorMessage(task.exception, true)
            }
        }
    }

    private fun authErrorMessage(ex: Exception?, registering: Boolean): String {
        val code = (ex as? com.google.firebase.auth.FirebaseAuthException)?.errorCode
            ?: ex?.javaClass?.simpleName ?: ""
        return when (code) {
            "ERROR_INVALID_EMAIL", "INVALID_EMAIL" ->
                "El correo electrónico no es válido."
            "ERROR_EMAIL_ALREADY_IN_USE", "EMAIL_EXISTS" ->
                "Ese correo ya tiene una cuenta. Pulsa ENTRAR."
            "ERROR_WEAK_PASSWORD", "WEAK_PASSWORD" ->
                "La contraseña es muy débil. Usa al menos 8 caracteres."
            "ERROR_WRONG_PASSWORD", "WRONG_PASSWORD" ->
                "La contraseña no es correcta."
            "ERROR_USER_NOT_FOUND", "USER_NOT_FOUND" ->
                "No existe una cuenta con ese correo. Pulsa CREAR CUENTA."
            "ERROR_INVALID_CREDENTIAL", "INVALID_CREDENTIAL" ->
                if (registering)
                    "Firebase rechazó los datos de registro. Revisa el correo y usa una contraseña de 8+ caracteres."
                else
                    "El correo o la contraseña no coinciden."
            "ERROR_OPERATION_NOT_ALLOWED", "OPERATION_NOT_ALLOWED" ->
                "El registro por correo está desactivado en Firebase."
            "ERROR_TOO_MANY_REQUESTS", "TOO_MANY_ATTEMPTS_TRY_LATER" ->
                "Demasiados intentos. Espera unos minutos y vuelve a intentarlo."
            "ERROR_NETWORK_REQUEST_FAILED" ->
                "No hay conexión con Firebase. Revisa Internet e inténtalo otra vez."
            else ->
                "No se pudo ${if (registering) "crear la cuenta" else "entrar"}: ${ex?.localizedMessage ?: "error de Firebase"}"
        }
    }

    private fun loadUserAndOpen() {
        val user = auth.currentUser ?: return showLogin()
        val userRef = db.collection("users").document(user.uid)
        userRef.get().addOnSuccessListener { doc ->
            val roleFromDoc = doc.getString("role") ?: doc.getString("Role")
            val knownAdmin = isKnownAdminEmail(user.email)
            val isAdmin = isAdminRole(roleFromDoc) || knownAdmin

            // Datos base que siempre se mantienen actualizados.
            val base = hashMapOf<String, Any>(
                "email" to (user.email ?: ""),
                "createdAt" to (doc.getLong("createdAt") ?: System.currentTimeMillis())
            )
            // Si es un correo de administrador conocido, forzamos role=admin para que
            // ambos administradores queden con los mismos permisos (sin limitaciones).
            if (knownAdmin) {
                base["role"] = "admin"
            }
            userRef.set(base, SetOptions.merge())

            // Guarda el token FCM y suscribe al topic de avisos generales
            // para que lleguen notificaciones de mensajes y avisos.
            val messaging = FirebaseMessaging.getInstance()
            messaging.token.addOnSuccessListener { token ->
                userRef.set(mapOf("fcmToken" to token), SetOptions.merge())
            }
            messaging.subscribeToTopic(MyFirebaseMessagingService.TOPIC_AVISOS)
                .addOnSuccessListener {
                    android.util.Log.d("MainActivity", "Suscrito a topic avisos_generales")
                }
                .addOnFailureListener { e ->
                    android.util.Log.w("MainActivity", "No se pudo suscribir a avisos: ${e.message}")
                }
            openApp(isAdmin)
        }.addOnFailureListener { openApp(false) }
    }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = filePathCallback ?: return@registerForActivityResult
        filePathCallback = null

        val data = result.data
        val results = if (result.resultCode == Activity.RESULT_OK && data != null) {
            val clip = data.clipData
            when {
                clip != null && clip.itemCount > 0 -> Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                data.data != null -> arrayOf(data.data!!)
                else -> null
            }
        } else {
            null
        }

        callback.onReceiveValue(results)
    }

    private val mediaUploadLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val cb = mediaUploadCallback
        mediaUploadCallback = null
        if (cb.isNullOrBlank()) return@registerForActivityResult
        val data = result.data
        if (result.resultCode != Activity.RESULT_OK || data?.data == null) {
            evaluateJsCallback(cb, false, null, "Selección cancelada")
            return@registerForActivityResult
        }
        val uri = data.data!!
        uploadMediaToStorage(uri, cb)
    }

    private fun evaluateJsCallback(callback: String, ok: Boolean, url: String?, message: String?) {
        val webView = appWebView ?: return
        val urlJson = if (url != null) JSONObject.quote(url) else "null"
        val msgJson = JSONObject.quote(message ?: "")
        val js = "window.$callback($ok, $urlJson, $msgJson);"
        webView.post { webView.evaluateJavascript(js, null) }
    }

    private fun uploadMediaToStorage(uri: Uri, callback: String) {
        val user = auth.currentUser
        if (user == null) {
            evaluateJsCallback(callback, false, null, "Usuario no autenticado")
            return
        }
        val contentResolver = contentResolver
        val mime = contentResolver.getType(uri) ?: mediaUploadMime ?: "application/octet-stream"
        val isVideo = mime.startsWith("video/")
        val isAudio = mime.startsWith("audio/")
        if (!isVideo && !isAudio) {
            evaluateJsCallback(callback, false, null, "Solo se permiten archivos de video o audio")
            return
        }
        val ext = when {
            mime.contains("mp4") -> "mp4"
            mime.contains("webm") -> "webm"
            mime.contains("3gp") -> "3gp"
            mime.contains("mpeg") || mime.contains("mp3") -> "mp3"
            mime.contains("aac") -> "aac"
            mime.contains("ogg") -> "ogg"
            mime.contains("wav") -> "wav"
            isVideo -> "mp4"
            else -> "mp3"
        }
        val path = "publications/${user.uid}/${System.currentTimeMillis()}.$ext"
        val ref = FirebaseStorage.getInstance().reference.child(path)
        ref.putFile(uri)
            .addOnSuccessListener {
                ref.downloadUrl
                    .addOnSuccessListener { downloadUri ->
                        evaluateJsCallback(callback, true, downloadUri.toString(), null)
                    }
                    .addOnFailureListener { e ->
                        evaluateJsCallback(callback, false, null, e.localizedMessage ?: "No se pudo obtener la URL")
                    }
            }
            .addOnFailureListener { e ->
                evaluateJsCallback(callback, false, null, e.localizedMessage ?: "Error al subir el archivo")
            }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun openApp(isAdmin: Boolean) {
        val webView = WebView(this)
        appWebView = webView
        val uidForActivity = auth.currentUser?.uid ?: ""
        val emailForActivity = auth.currentUser?.email ?: ""
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        val nativeBridge = NativeAppBridge(db, auth.currentUser?.uid ?: "", auth.currentUser?.email ?: "", isAdmin, webView)
        webView.setTag(nativeBridge)
        webView.addJavascriptInterface(nativeBridge, "NativeApp")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePath: ValueCallback<Array<android.net.Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePath
                val acceptType = fileChooserParams?.acceptTypes
                    ?.flatMap { it.split(",") }
                    ?.firstOrNull { it.isNotBlank() } ?: "*/*"
                val isImage = acceptType.startsWith("image/")
                val intent = if (isImage) {
                    Intent(Intent.ACTION_PICK).apply {
                        type = "image/*"
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                } else {
                    Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        type = acceptType
                        addCategory(Intent.CATEGORY_OPENABLE)
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                    }
                }
                return try {
                    fileChooserLauncher.launch(Intent.createChooser(intent, "Selecciona un archivo"))
                    true
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback?.onReceiveValue(null)
                    this@MainActivity.filePathCallback = null
                    false
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                val adminValue = if (isAdmin) "true" else "false"
                view?.evaluateJavascript("window.__nativeAdmin='$adminValue'; localStorage.setItem('cep_native_admin','$adminValue');", null)
                if (uidForActivity.isNotBlank()) db.collection("appActivity").add(mapOf("uid" to uidForActivity, "email" to emailForActivity, "action" to "inicio_app", "detail" to "", "createdAt" to System.currentTimeMillis()))
            }
        }
        appWebView = webView
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val wv = appWebView
                if (wv == null) {
                    finish()
                    return
                }
                wv.evaluateJavascript("(window.handleAndroidBack ? window.handleAndroidBack() : 'exit')") { result ->
                    if (result == null || result.contains("exit")) {
                        finish()
                    }
                }
            }
        })
    }

    inner class NativeAppBridge(
        private val db: FirebaseFirestore,
        private val uid: String,
        private val email: String,
        private var adminRole: Boolean,
        private val webView: WebView
    ) {
        private var clientSenderListener: ListenerRegistration? = null
        private var clientRecipientListener: ListenerRegistration? = null
        private val adminInboxListeners = mutableListOf<ListenerRegistration>()

        @JavascriptInterface fun isAdmin(): String = if (adminRole) "true" else "false"

        @JavascriptInterface
        fun refreshAdminStatus(callback: String) {
            if (uid.isBlank()) { callbackOnUi(callback, false); return }
            db.collection("users").document(uid).get()
                .addOnSuccessListener { doc ->
                    val role1 = doc.getString("role")
                    val role2 = doc.getString("Role")
                    adminRole = MainActivity.isAdminRole(role1) || MainActivity.isAdminRole(role2) || MainActivity.isKnownAdminEmail(email)
                    // Asegura que el documento tenga role=admin si es administrador conocido.
                    if (adminRole && !MainActivity.isAdminRole(role1) && !MainActivity.isAdminRole(role2)) {
                        db.collection("users").document(uid).set(mapOf("role" to "admin"), SetOptions.merge())
                    }
                    callbackOnUi(callback, adminRole)
                }
                .addOnFailureListener { callbackOnUi(callback, adminRole, it.localizedMessage ?: "No se pudo comprobar el rol") }
        }

        private fun requireAdmin(callback: String, action: (Boolean) -> Unit) {
            if (uid.isBlank()) { callbackOnUi(callback, false, "Usuario no autenticado"); return }
            db.collection("users").document(uid).get()
                .addOnSuccessListener { doc ->
                    val role1 = doc.getString("role")
                    val role2 = doc.getString("Role")
                    adminRole = MainActivity.isAdminRole(role1) || MainActivity.isAdminRole(role2) || MainActivity.isKnownAdminEmail(email)
                    if (adminRole && !MainActivity.isAdminRole(role1) && !MainActivity.isAdminRole(role2)) {
                        db.collection("users").document(uid).set(mapOf("role" to "admin"), SetOptions.merge())
                    }
                    action(adminRole)
                }
                .addOnFailureListener { action(adminRole) }
        }
        @JavascriptInterface fun currentUid(): String = uid
        @JavascriptInterface fun currentEmail(): String = email

        @JavascriptInterface
        fun logActivity(action: String, detail: String) {
            if (uid.isBlank()) return
            val cleanAction = action.trim().take(80)
            val cleanDetail = detail.trim().take(200)
            if (cleanAction.isBlank()) return
            val payload = hashMapOf<String, Any>(
                "uid" to uid,
                "email" to (email.ifBlank { "" }),
                "action" to cleanAction,
                "detail" to cleanDetail,
                "createdAt" to System.currentTimeMillis()
            )
            db.collection("appActivity").add(payload)
                .addOnFailureListener { e ->
                    android.util.Log.e("NativeApp", "No se pudo registrar actividad '$cleanAction': ${e.message}", e)
                }
        }

        @JavascriptInterface
        fun loadActivity(callback: String) {
            requireAdmin(callback) { allowed ->
                if (!allowed) { callbackOnUi(callback, JSONArray(), "La sesión actual no tiene rol admin."); return@requireAdmin }
                db.collection("appActivity").orderBy("createdAt", Query.Direction.DESCENDING).limit(100).get()
                .addOnSuccessListener { snap ->
                    val arr = JSONArray()
                    snap.documents.forEach { d ->
                        arr.put(JSONObject().apply {
                            put("uid", d.getString("uid") ?: "")
                            put("email", d.getString("email") ?: "")
                            put("action", d.getString("action") ?: "")
                            put("detail", d.getString("detail") ?: "")
                            put("createdAt", d.getLong("createdAt") ?: 0L)
                        })
                    }
                    callbackOnUi(callback, arr)
                }
                .addOnFailureListener { error ->
                    android.util.Log.e("NativeApp", "No se pudo cargar appActivity: ${(error as? com.google.firebase.firestore.FirebaseFirestoreException)?.code?.name ?: (error.localizedMessage ?: "error")}", error)
                    callbackOnUi(callback, JSONArray(), "No se pudo cargar la actividad: ${(error as? com.google.firebase.firestore.FirebaseFirestoreException)?.code?.name ?: (error.localizedMessage ?: "error")}")
                }
            }
        }

        @JavascriptInterface
        fun sharePublication(channel: String, title: String, text: String) {
            val pkg = when (channel.lowercase()) {
                "whatsapp" -> "com.whatsapp"
                "facebook" -> "com.facebook.katana"
                else -> ""
            }
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, title.take(120))
                putExtra(Intent.EXTRA_TEXT, text.take(2000))
                if (pkg.isNotBlank()) `package` = pkg
            }
            webView.post {
                try {
                    webView.context.startActivity(intent)
                } catch (_: Exception) {
                    val fallback = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, title.take(120))
                        putExtra(Intent.EXTRA_TEXT, text.take(2000))
                    }
                    try { webView.context.startActivity(Intent.createChooser(fallback, "Compartir publicación")) } catch (_: Exception) { }
                }
            }
        }

        @JavascriptInterface
        fun subscribePrivateMessages(callback: String) {
            if (uid.isBlank()) { callbackOnUi(callback, JSONArray()); return }
            clientSenderListener?.remove()
            clientRecipientListener?.remove()
            val all = linkedMapOf<String, JSONObject>()
            var first = true
            fun publish() {
                val arr = JSONArray()
                all.values.sortedBy { it.optLong("createdAt") }.forEach { arr.put(it) }
                callbackOnUi(callback, arr)
            }
            clientSenderListener = db.collection("privateMessages")
                .whereEqualTo("senderUid", uid)
                .addSnapshotListener { snap, _ ->
                    if (snap != null) { snap.documents.forEach { all[it.id] = messageJson(it) }; publish() }
                }
            clientRecipientListener = db.collection("privateMessages")
                .whereEqualTo("recipientUid", uid)
                .addSnapshotListener { snap, _ ->
                    if (snap != null) { snap.documents.forEach { all[it.id] = messageJson(it) }; publish() }
                }
        }

        @JavascriptInterface
        fun subscribeAdminInbox(callback: String) {
            requireAdmin(callback) { allowed ->
                if (!allowed) {
                    callbackOnUi(callback, JSONArray(), "La sesión actual no tiene rol admin.")
                    return@requireAdmin
                }

            adminInboxListeners.forEach { it.remove() }
            adminInboxListeners.clear()

            // Bandeja completa del administrador:
            // cliente -> ADMIN y ADMIN -> cliente.
            val all = linkedMapOf<String, JSONObject>()

            fun publish() {
                val arr = JSONArray()
                all.values.sortedBy { it.optLong("createdAt") }.forEach { arr.put(it) }
                callbackOnUi(callback, arr)
            }

            val incoming = db.collection("privateMessages")
                .whereEqualTo("recipientUid", "ADMIN")
                .addSnapshotListener { snap, error ->
                    if (error != null) {
                        android.util.Log.e("NativeApp", "Error leyendo mensajes cliente->admin: ${(error as? com.google.firebase.firestore.FirebaseFirestoreException)?.code?.name ?: (error.localizedMessage ?: "error")}", error)
                        callbackOnUi(callback, JSONArray(), "Firestore: ${(error as? com.google.firebase.firestore.FirebaseFirestoreException)?.code?.name ?: (error.localizedMessage ?: "error")} — ${error.localizedMessage ?: "sin detalle"}")
                        return@addSnapshotListener
                    }
                    snap?.documents?.forEach { all[it.id] = messageJson(it) }
                    publish()
                }

            val outgoing = db.collection("privateMessages")
                .whereEqualTo("senderUid", uid)
                .addSnapshotListener { snap, error ->
                    if (error != null) {
                        android.util.Log.e("NativeApp", "Error leyendo respuestas admin: ${(error as? com.google.firebase.firestore.FirebaseFirestoreException)?.code?.name ?: (error.localizedMessage ?: "error")}", error)
                        callbackOnUi(callback, JSONArray(), "Firestore: ${(error as? com.google.firebase.firestore.FirebaseFirestoreException)?.code?.name ?: (error.localizedMessage ?: "error")} — ${error.localizedMessage ?: "sin detalle"}")
                        return@addSnapshotListener
                    }
                    snap?.documents?.forEach { all[it.id] = messageJson(it) }
                    publish()
                }

            adminInboxListeners += incoming
            adminInboxListeners += outgoing
            }
        }

        @JavascriptInterface
        fun unsubscribePrivateMessages() {
            clientSenderListener?.remove(); clientSenderListener = null
            clientRecipientListener?.remove(); clientRecipientListener = null
        }

        @JavascriptInterface
        fun releaseListeners() {
            unsubscribePrivateMessages()
            adminInboxListeners.forEach { it.remove() }; adminInboxListeners.clear()
        }

        @JavascriptInterface
        fun loadPrivateMessages(callback: String) {
            if (uid.isBlank()) { callbackOnUi(callback, JSONArray()); return }
            val results = mutableListOf<JSONObject>()
            var pending = 2
            fun finish() {
                pending--
                if (pending <= 0) {
                    results.sortBy { it.optLong("createdAt") }
                    val arr = JSONArray(); results.forEach { arr.put(it) }
                    callbackOnUi(callback, arr)
                }
            }
            db.collection("privateMessages").whereEqualTo("senderUid", uid).get()
                .addOnSuccessListener { snap -> snap.documents.forEach { results.add(messageJson(it)) }; finish() }
                .addOnFailureListener { finish() }
            db.collection("privateMessages").whereEqualTo("recipientUid", uid).get()
                .addOnSuccessListener { snap -> snap.documents.forEach { results.add(messageJson(it)) }; finish() }
                .addOnFailureListener { finish() }
        }

        @JavascriptInterface
        fun loadAdminInbox(callback: String) {
            requireAdmin(callback) { allowed ->
                if (!allowed) {
                    callbackOnUi(callback, JSONArray(), "La sesión actual no tiene rol admin.")
                    return@requireAdmin
                }
            val results = mutableMapOf<String, JSONObject>()
            var pending = 2
            var firstError: String? = null
            fun finish() {
                pending--
                if (pending == 0) {
                    val arr = JSONArray()
                    results.values.sortedBy { it.optLong("createdAt") }.forEach { arr.put(it) }
                    callbackOnUi(callback, arr, firstError)
                }
            }
            db.collection("privateMessages").whereEqualTo("recipientUid", "ADMIN").get()
                .addOnSuccessListener { snap -> snap.documents.forEach { results[it.id] = messageJson(it) }; finish() }
                .addOnFailureListener { e -> firstError = "Firestore: ${e.message ?: e.javaClass.simpleName}"; finish() }
            db.collection("privateMessages").whereEqualTo("senderUid", uid).get()
                .addOnSuccessListener { snap -> snap.documents.forEach { results[it.id] = messageJson(it) }; finish() }
                .addOnFailureListener { e -> if (firstError == null) firstError = "Firestore: ${e.message ?: e.javaClass.simpleName}"; finish() }
            }
        }

        @JavascriptInterface
        fun sendPrivateMessage(recipientUid: String, text: String, callback: String) {
            val clean = text.trim()
            if (uid.isBlank() || clean.isBlank()) {
                callbackOnUi(callback, false, "Mensaje vacío o usuario no autenticado")
                return
            }
            val target = if (recipientUid == "ADMIN") "ADMIN" else recipientUid
            val data = hashMapOf<String, Any>(
                "senderUid" to uid,
                "senderEmail" to email,
                "recipientUid" to target,
                "text" to clean,
                "createdAt" to System.currentTimeMillis(),
                "read" to false
            )
            db.collection("privateMessages").add(data)
                .addOnSuccessListener { callbackOnUi(callback, true) }
                .addOnFailureListener { e -> callbackOnUi(callback, false, e.localizedMessage ?: "Error de Firestore") }
        }

        @JavascriptInterface
        fun markPrivateMessageRead(messageId: String) {
            if (messageId.isBlank()) return
            requireAdmin("__ignore__") { allowed ->
                if (allowed) db.collection("privateMessages").document(messageId).update("read", true)
            }
        }


        private fun firestoreValueToJson(value: Any?): Any? {
            return when (value) {
                is Map<*, *> -> {
                    val o = JSONObject()
                    value.forEach { (k, v) -> if (k != null) o.put(k.toString(), firestoreValueToJson(v)) }
                    o
                }
                is List<*> -> JSONArray(value.map { firestoreValueToJson(it) })
                else -> value
            }
        }

        private fun jsonValueToFirestore(value: Any?): Any? {
            return when (value) {
                is JSONObject -> {
                    val m = hashMapOf<String, Any>()
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        val v = value.get(k)
                        if (v != JSONObject.NULL) jsonValueToFirestore(v)?.let { m[k] = it }
                    }
                    m
                }
                is JSONArray -> {
                    val list = mutableListOf<Any>()
                    for (i in 0 until value.length()) {
                        jsonValueToFirestore(value.get(i))?.let { list.add(it) }
                    }
                    list
                }
                is String, is Boolean, is Number -> value
                else -> value?.toString()
            }
        }

        @JavascriptInterface
        fun loadAppSettings(callback: String) {
            db.collection("appSettings").document("main").get()
                .addOnSuccessListener { doc ->
                    val obj = JSONObject()
                    doc.data?.forEach { (k, v) -> obj.put(k, firestoreValueToJson(v)) }
                    callbackOnUi(callback, obj)
                }
                .addOnFailureListener { callbackOnUi(callback, JSONObject()) }
        }

        @JavascriptInterface
        fun saveAppSettings(json: String, callback: String) {
            requireAdmin(callback) { allowed ->
                if (!allowed) { callbackOnUi(callback, false, "La sesión actual no tiene rol admin."); return@requireAdmin }
            try {
                val obj = JSONObject(json)
                val converted = jsonValueToFirestore(obj)
                @Suppress("UNCHECKED_CAST")
                val map = converted as? Map<String, Any> ?: throw IllegalArgumentException("Configuración inválida")
                db.collection("appSettings").document("main").set(map, SetOptions.merge())
                    .addOnSuccessListener { callbackOnUi(callback, true) }
                    .addOnFailureListener { e -> callbackOnUi(callback, false, e.localizedMessage ?: "Error de Firebase") }
            } catch (e: Exception) {
                callbackOnUi(callback, false, "Configuración inválida: ${e.localizedMessage ?: "error"}")
            }
            }
        }

        /**
         * Abre el selector de archivos para video o audio, sube a Firebase Storage
         * y devuelve la URL de descarga al callback JS: window.callback(ok, url, message)
         */
        @JavascriptInterface
        fun pickAndUploadPublicationMedia(callback: String) {
            requireAdmin(callback) { allowed ->
                if (!allowed) {
                    this@MainActivity.evaluateJsCallback(callback, false, null, "La sesión actual no tiene rol admin.")
                    return@requireAdmin
                }
                this@MainActivity.mediaUploadCallback = callback
                this@MainActivity.mediaUploadMime = null
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "audio/*"))
                    addCategory(Intent.CATEGORY_OPENABLE)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                try {
                    this@MainActivity.mediaUploadLauncher.launch(Intent.createChooser(intent, "Selecciona video o música"))
                } catch (e: Exception) {
                    this@MainActivity.mediaUploadCallback = null
                    this@MainActivity.evaluateJsCallback(callback, false, null, e.localizedMessage ?: "No se pudo abrir el selector")
                }
            }
        }

        // ---------- Cuentas de clientes ----------
        // El administrador crea una cuenta de saldo asociada al correo del cliente.
        @JavascriptInterface
        fun loadMyClientAccount(callback: String) {
            if (uid.isBlank() || email.isBlank()) { callbackOnUi(callback, JSONArray()); return }
            val normalizedEmail = email.trim().lowercase()
            val byEmail = db.collection("clientAccounts")
                .whereEqualTo("customerEmail", normalizedEmail).get()
            val byUid = db.collection("clientAccounts")
                .whereEqualTo("customerUid", uid).get()

            com.google.android.gms.tasks.Tasks.whenAllSuccess<com.google.firebase.firestore.QuerySnapshot>(byEmail, byUid)
                .addOnSuccessListener { results ->
                    val seen = mutableSetOf<String>()
                    val arr = JSONArray()
                    results.forEach { snap ->
                        snap.documents.forEach { doc ->
                            if (seen.add(doc.id)) arr.put(accountJson(doc))
                        }
                    }
                    callbackOnUi(callback, arr)
                }
                .addOnFailureListener { callbackOnUi(callback, JSONArray()) }
        }

        @JavascriptInterface
        fun loadAllClientAccounts(callback: String) {
            requireAdmin(callback) { allowed ->
                if (!allowed) { callbackOnUi(callback, JSONArray(), "La sesión actual no tiene rol admin."); return@requireAdmin }
            db.collection("clientAccounts").orderBy("customerName", Query.Direction.ASCENDING).get()
                .addOnSuccessListener { snap ->
                    val arr = JSONArray(); snap.documents.forEach { arr.put(accountJson(it)) }
                    callbackOnUi(callback, arr)
                }
                .addOnFailureListener { e -> callbackOnUi(callback, JSONArray(), e.localizedMessage ?: "Error de Firestore") }
            }
        }

        @JavascriptInterface
        fun createClientAccount(name: String, customerEmail: String, total: Double, callback: String) {
            if (name.trim().isBlank() || customerEmail.trim().isBlank()) { callbackOnUi(callback, false, "Faltan datos del cliente"); return }
            requireAdmin(callback) { allowed ->
                if (!allowed) { callbackOnUi(callback, false, "La sesión actual no tiene rol admin."); return@requireAdmin }
            val data = hashMapOf<String, Any>(
                "customerName" to name.trim(),
                "customerEmail" to customerEmail.trim().lowercase(),
                "customerUid" to if (customerEmail.trim().equals(email, ignoreCase = true)) uid else "",
                "total" to total.coerceAtLeast(0.0),
                "paid" to 0.0,
                "createdAt" to System.currentTimeMillis()
            )
            db.collection("clientAccounts").add(data)
                .addOnSuccessListener { callbackOnUi(callback, true) }
                .addOnFailureListener { e -> callbackOnUi(callback, false, e.localizedMessage ?: "Error de Firestore") }
            }
        }

        @JavascriptInterface
        fun addClientPayment(accountId: String, amount: Double, callback: String) {
            if (accountId.isBlank() || amount <= 0) { callbackOnUi(callback, false, "Datos de abono inválidos"); return }
            requireAdmin(callback) { allowed ->
                if (!allowed) { callbackOnUi(callback, false, "La sesión actual no tiene rol admin."); return@requireAdmin }
            val ref = db.collection("clientAccounts").document(accountId)
            db.runTransaction { tx ->
                val snap = tx.get(ref)
                val oldPaid = snap.getDouble("paid") ?: 0.0
                tx.update(ref, "paid", oldPaid + amount)
            }.addOnSuccessListener { callbackOnUi(callback, true) }
                .addOnFailureListener { e -> callbackOnUi(callback, false, e.localizedMessage ?: "Error de Firestore") }
            }
        }

        @JavascriptInterface
        fun deletePaidClientAccount(accountId: String, callback: String) {
            if (accountId.isBlank()) { callbackOnUi(callback, false, "Cuenta inválida"); return }
            requireAdmin(callback) { allowed ->
                if (!allowed) { callbackOnUi(callback, false, "No autorizado"); return@requireAdmin }
            val ref = db.collection("clientAccounts").document(accountId)
            ref.get()
                .addOnSuccessListener { snap ->
                    if (!snap.exists()) {
                        callbackOnUi(callback, false, "La cuenta ya no existe.")
                        return@addOnSuccessListener
                    }
                    val total = snap.getDouble("total") ?: 0.0
                    val paid = snap.getDouble("paid") ?: 0.0
                    if (paid + 0.005 < total) {
                        callbackOnUi(callback, false, "Solo puedes borrar una cuenta cuando esté totalmente pagada.")
                        return@addOnSuccessListener
                    }
                    ref.delete()
                        .addOnSuccessListener { callbackOnUi(callback, true) }
                        .addOnFailureListener { e -> callbackOnUi(callback, false, e.localizedMessage ?: "Error de Firebase") }
                }
                .addOnFailureListener { e -> callbackOnUi(callback, false, e.localizedMessage ?: "Error de Firebase") }
            }
        }

        private fun accountJson(doc: com.google.firebase.firestore.DocumentSnapshot): JSONObject {
            return JSONObject().apply {
                put("id", doc.id)
                put("customerName", doc.getString("customerName") ?: "")
                put("customerEmail", doc.getString("customerEmail") ?: "")
                put("total", doc.getDouble("total") ?: 0.0)
                put("paid", doc.getDouble("paid") ?: 0.0)
                put("createdAt", doc.getLong("createdAt") ?: 0L)
            }
        }

        private fun messageJson(doc: com.google.firebase.firestore.DocumentSnapshot): JSONObject {
            return JSONObject().apply {
                put("id", doc.id)
                put("senderUid", doc.getString("senderUid") ?: "")
                put("senderEmail", doc.getString("senderEmail") ?: "")
                put("recipientUid", doc.getString("recipientUid") ?: "")
                put("text", doc.getString("text") ?: "")
                put("createdAt", doc.getLong("createdAt") ?: 0L)
                put("read", doc.getBoolean("read") ?: false)
                put("sourceMessageId", doc.getString("sourceMessageId") ?: "")
                put("fanoutForAdmin", doc.getBoolean("fanoutForAdmin") ?: false)
            }
        }

        private fun callbackOnUi(callback: String, value: Any, message: String? = null) {
            val jsValue = when (value) {
                is JSONArray -> value.toString()
                is JSONObject -> value.toString()
                is Boolean -> value.toString()
                else -> "false"
            }
            val msgJson = JSONObject.quote(message ?: "")
            val js = "window.$callback($jsValue,$msgJson);"
            webView.post { webView.evaluateJavascript(js, null) }
        }
    }
}
