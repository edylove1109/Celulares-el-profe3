# Celulares El Profe — V22
Versión con permisos de administrador igualados y registro de actividad corregido.

## Cambios de esta versión (permisos y actividad)
- Ambos administradores tienen **exactamente los mismos permisos**, sin limitaciones especiales de uno sobre el otro.
- El acceso de administrador se basa en `role = admin` en `users/{uid}` (y opcionalmente en una lista de correos conocidos para bootstrap).
- Al iniciar sesión, si el correo está en la lista de administradores, se fuerza `role = admin` automáticamente.
- Los administradores pueden actualizar documentos de otros usuarios (por ejemplo, para asignar el rol admin al segundo administrador).
- El registro de actividad de usuarios (`appActivity`) se guarda correctamente y cualquier administrador puede consultarlo.
- Reglas de Firestore actualizadas para reflejar lo anterior.

IMPORTANTE:
1. Publica las reglas: `firebase deploy --only firestore:rules`
2. Publica las Cloud Functions de notificaciones (requiere plan Blaze):
   ```bash
   firebase deploy --only functions:notifyPrivateMessage,functions:notifyAppNotice
   ```
   - `notifyPrivateMessage` → push cuando hay mensajes privados
   - `notifyAppNotice` → push a todos cuando el admin publica un aviso
3. Administradores configurados (ambos con los mismos permisos):
   - `juancarlospelayolepe7@gmail.com`
   - `manololepe25@gmail.com`
   Al iniciar sesión se les asigna automáticamente `role = admin`.
4. Genera el APK desde GitHub Actions e instálalo.
5. En el teléfono: permite notificaciones cuando Android lo pida (Android 13+).
6. La cuenta de saldo no crea por sí sola una cuenta de acceso de Firebase; el cliente debe registrarse con el mismo correo.


## V16 — mensajes en tiempo real y notificaciones push

Esta versión mantiene Firebase Authentication y Firestore y añade:
- conversaciones privadas actualizadas en tiempo real con `addSnapshotListener`;
- notificaciones Android con Firebase Cloud Messaging;
- guardado automático del token FCM en `users/{uid}.fcmToken`;
- Cloud Function `notifyPrivateMessage` que envía una notificación al destinatario cuando se crea un documento en `privateMessages`;
- si el destinatario es `ADMIN`, la función notifica a los usuarios cuyo `role` es `admin`.

### Activar el envío automático de notificaciones

El APK queda preparado desde el código, pero el envío servidor→teléfono requiere desplegar la Cloud Function. Firebase indica que Cloud Functions requiere el plan Blaze. No es necesario cambiar de plan para compilar el APK, pero sí para desplegar esta función.

Desde Firebase/Google Cloud Shell, en la carpeta raíz del proyecto:

```bash
firebase login
firebase use celulares-el-profe
firebase deploy --only functions:notifyPrivateMessage
```

Después de desplegarla, cualquier nuevo mensaje en `privateMessages` generará la notificación push.

## V17/V18 — punto importante de despliegue
El APK por sí solo NO despliega las reglas de Firestore ni las Cloud Functions. Después de publicar esta versión, desde la raíz del proyecto ejecuta:

```bash
firebase login
firebase use celulares-el-profe
firebase deploy --only firestore:rules,functions:notifyPrivateMessage
```

La función necesita estar realmente desplegada para enviar FCM. Las reglas incluidas permiten al administrador leer los mensajes dirigidos a `ADMIN` y a cada usuario leer sus propios mensajes.

V19 MENSAJERIA ADMIN: la bandeja del administrador lee directamente privateMessages donde recipientUid == ADMIN. No depende de fan-out de Cloud Functions para mostrar mensajes. Las notificaciones push siguen requiriendo el despliegue de functions/notifyPrivateMessage.

## V21 — Mensajes y notificaciones
- La bandeja admin escucha mensajes cliente->ADMIN y respuestas ADMIN->cliente.
- Las conversaciones se separan por cliente y muestran ambos sentidos.
- La Cloud Function `notifyPrivateMessage` ya no crea fan-out innecesario.
- Para notificaciones push hay que desplegar `functions/index.js` en Firebase.
